"""
External or vendor files
"""
